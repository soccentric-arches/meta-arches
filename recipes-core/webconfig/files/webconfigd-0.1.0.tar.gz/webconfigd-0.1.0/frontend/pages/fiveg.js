import { renderNetworkPage } from './network.js';

export function render(api, store) {
    return renderNetworkPage(api, store, '5g');
}
